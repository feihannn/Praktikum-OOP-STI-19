public interface Calculator{
    public int plus(int angka1);
    public int minus(int angka2);
    public int checkBattery();
}