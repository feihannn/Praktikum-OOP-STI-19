/**
 * Vampir.java
 * [Jelaskan kegunaan class ini]
 * @author 18219006 MARCELINO FEIHAN
 */
public class Pocong extends Setan{
    public Pocong(){
        super("Pocong","Indonesia");
    }
    public void sayHi(){
        System.out.println("Punten! Aku "+getNama()+". Aku Dari "+getNegara()+".");
    }
}
